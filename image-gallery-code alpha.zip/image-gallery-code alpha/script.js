document.addEventListener("DOMContentLoaded", () => {
    let nextButton = document.querySelector(".next");
    let prevButton = document.querySelector(".prev");

    nextButton.addEventListener("click", function() {
        let items = document.querySelectorAll(".item");
        let slide = document.querySelector(".slide");
        slide.appendChild(items[0]);
    });

    prevButton.addEventListener("click", function() {
        let items = document.querySelectorAll(".item");
        let slide = document.querySelector(".slide");
        slide.prepend(items[items.length - 1]);
    });
});
